# AK Solutions and Services - Static Website

A premium responsive React + Vite static website based on the AK Solutions and Services brand direction.

## Requirements

- Node.js 18+ recommended
- npm

## Run locally

```bash
npm install
npm run dev
```

Open the URL shown by Vite, normally:

http://localhost:5173

## Production build

```bash
npm run build
```

The production files are generated in:

```text
dist/
```

## Important

Before production deployment, replace the placeholder contact details in:

```text
src/App.jsx
```

Add the final company logo when available. The current AK mark is a CSS/text treatment so the website can be developed before the final logo asset is supplied.

## Suggested next steps

1. Add the final logo.
2. Add WhatsApp button.
3. Add a real contact/inquiry form.
4. Add Google Maps.
5. Add domain + HTTPS.
6. Deploy the static build to AWS S3 + CloudFront or an EC2/Nginx server.
