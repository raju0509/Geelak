import { useState } from "react";

const services = [
  {
    number: "01",
    icon: "⌘",
    title: "Software Development",
    text: "Custom web, mobile and business applications designed for performance, usability and growth.",
    tags: ["Web Apps", "Mobile Apps", "Business Solutions"],
  },
  {
    number: "02",
    icon: "✓",
    title: "QA & Testing",
    text: "Quality engineering backed by 15+ years of QA leadership across manual and automation testing.",
    tags: ["Manual Testing", "Automation", "API Testing"],
  },
  {
    number: "03",
    icon: "☁",
    title: "Cloud Solutions",
    text: "Cloud migration, infrastructure setup and reliable cloud environments built around your business needs.",
    tags: ["AWS", "Azure", "Cloud Migration"],
  },
  {
    number: "04",
    icon: "∞",
    title: "DevOps & Automation",
    text: "CI/CD, infrastructure automation and deployment practices that help teams release faster and more reliably.",
    tags: ["CI/CD", "Docker", "Kubernetes"],
  },
  {
    number: "05",
    icon: "◌",
    title: "IT Support & Maintenance",
    text: "Proactive application and infrastructure support to keep your systems available, secure and healthy.",
    tags: ["Monitoring", "Support", "Maintenance"],
  },
];

const approach = [
  ["01", "Understand", "We listen, analyze your needs and understand the business problem before proposing technology."],
  ["02", "Plan", "We design a practical solution with clear scope, priorities, milestones and delivery expectations."],
  ["03", "Execute", "We build, test and continuously improve with quality and engineering discipline."],
  ["04", "Deliver", "We deploy reliable solutions and provide the support needed after launch."],
  ["05", "Grow", "We stay with you as your requirements evolve and your business scales."],
];

function App() {
  const [menuOpen, setMenuOpen] = useState(false);

  const closeMenu = () => setMenuOpen(false);

  return (
    <div className="site">
      <header className="navbar">
        <a href="#home" className="brand" onClick={closeMenu}>
          <span className="brand-mark">AK</span>
          <span className="brand-copy">
            <strong>AK SOLUTIONS</strong>
            <small>AND SERVICES</small>
          </span>
        </a>

        <button
          className="menu-button"
          aria-label="Toggle navigation"
          onClick={() => setMenuOpen(!menuOpen)}
        >
          <span></span><span></span><span></span>
        </button>

        <nav className={menuOpen ? "nav-links open" : "nav-links"}>
          <a href="#home" onClick={closeMenu}>Home</a>
          <a href="#about" onClick={closeMenu}>About</a>
          <a href="#services" onClick={closeMenu}>Services</a>
          <a href="#approach" onClick={closeMenu}>Approach</a>
          <a href="#contact" className="nav-cta" onClick={closeMenu}>Start a Project</a>
        </nav>
      </header>

      <main>
        <section id="home" className="hero section">
          <div className="hero-glow"></div>
          <div className="hero-content">
            <div className="eyebrow"><span></span> IT SERVICES • CLOUD • QUALITY</div>
            <h1>Your Vision.<br /><em>Our Expertise.</em></h1>
            <p className="hero-subtitle">
              Reliable technology solutions for startups, entrepreneurs and businesses
              ready to innovate, grow and succeed.
            </p>
            <div className="hero-actions">
              <a className="button primary" href="#contact">Let's Build Something</a>
              <a className="button secondary" href="#services">Explore Services <span>→</span></a>
            </div>
            <div className="hero-proof">
              <div><strong>15+</strong><span>Years QA Expertise</span></div>
              <div><strong>5</strong><span>Core Service Areas</span></div>
              <div><strong>100%</strong><span>Client Focused</span></div>
            </div>
          </div>

          <div className="hero-visual" aria-hidden="true">
            <div className="orb orb-one"></div>
            <div className="orb orb-two"></div>
            <div className="visual-card main-card">
              <div className="card-top"><span>AK</span><small>TECHNOLOGY PARTNER</small></div>
              <div className="dashboard-line long"></div>
              <div className="dashboard-line"></div>
              <div className="mini-grid">
                <div><b>DEV</b><span>Build</span></div>
                <div><b>QA</b><span>Quality</span></div>
                <div><b>OPS</b><span>Deliver</span></div>
              </div>
              <div className="growth-line">
                <span>BUSINESS GROWTH</span>
                <strong>↗</strong>
              </div>
            </div>
            <div className="floating-card card-quality">✓ <span>Quality First</span></div>
            <div className="floating-card card-cloud">☁ <span>Cloud Ready</span></div>
          </div>
        </section>

        <section id="about" className="section about">
          <div className="section-label">WHO WE ARE</div>
          <div className="about-grid">
            <div>
              <h2>Technology that works <span>for your business.</span></h2>
            </div>
            <div className="about-copy">
              <p>
                AK Solutions and Services is a technology services initiative focused on
                building practical, reliable and scalable digital solutions.
              </p>
              <p>
                Our strength combines software engineering, cloud & DevOps expertise and
                deep QA experience to help clients move from idea to dependable delivery.
              </p>
              <a href="#contact" className="text-link">Talk to us about your project →</a>
            </div>
          </div>
        </section>

        <section id="services" className="section services">
          <div className="section-heading">
            <div>
              <div className="section-label">WHAT WE DO</div>
              <h2>Our <span>Services</span></h2>
            </div>
            <p>From development and testing to cloud and operations, we provide the technology capabilities your business needs.</p>
          </div>

          <div className="service-grid">
            {services.map((service) => (
              <article className="service-card" key={service.number}>
                <div className="service-number">{service.number}</div>
                <div className="service-icon">{service.icon}</div>
                <h3>{service.title}</h3>
                <p>{service.text}</p>
                <div className="tag-list">
                  {service.tags.map((tag) => <span key={tag}>{tag}</span>)}
                </div>
                <a href="#contact" className="service-link">Discuss this service →</a>
              </article>
            ))}
          </div>
        </section>

        <section className="section qa-highlight">
          <div className="qa-number">15<span>+</span></div>
          <div className="qa-content">
            <div className="section-label">QUALITY ENGINEERING</div>
            <h2>Experience that puts <span>quality first.</span></h2>
            <p>
              Our QA leadership brings 15+ years of software quality experience, helping
              teams build confidence through structured testing, automation and quality engineering.
            </p>
            <div className="qa-pills">
              <span>Manual Testing</span><span>Automation Testing</span><span>API Testing</span>
              <span>Regression Testing</span><span>Test Strategy</span><span>Quality Engineering</span>
            </div>
          </div>
        </section>

        <section id="approach" className="section approach">
          <div className="section-heading centered">
            <div className="section-label">HOW WE WORK</div>
            <h2>Our <span>Approach</span></h2>
            <p>A simple, transparent process designed to turn business requirements into measurable outcomes.</p>
          </div>

          <div className="approach-grid">
            {approach.map(([number, title, text]) => (
              <div className="approach-item" key={number}>
                <div className="approach-number">{number}</div>
                <h3>{title}</h3>
                <p>{text}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="section why">
          <div className="section-label">WHY AK</div>
          <h2>Small team. <span>Big expertise.</span></h2>
          <div className="why-grid">
            {[
              ["◎", "Client Focused", "Solutions aligned with your actual business goals."],
              ["✦", "Practical Innovation", "Modern technology without unnecessary complexity."],
              ["★", "Quality & Reliability", "Engineering and testing discipline from start to finish."],
              ["↗", "Flexible Engagement", "Hourly, project-based or long-term collaboration."],
            ].map(([icon, title, text]) => (
              <div className="why-card" key={title}>
                <div>{icon}</div><h3>{title}</h3><p>{text}</p>
              </div>
            ))}
          </div>
        </section>

        <section id="contact" className="section contact">
          <div className="contact-panel">
            <div className="contact-left">
              <div className="section-label">LET'S CONNECT</div>
              <h2>Have a project<br /><span>in mind?</span></h2>
              <p>Let's turn your ideas into a reliable digital solution.</p>
              <a className="button primary" href="mailto:neeharika.nq@aksolutionsandservices.com">
                Start a Conversation
              </a>
            </div>
            <div className="contact-details">
              <div><small>EMAIL</small><a href="mailto:neeharika.nq@aksolutionsandservices.com">neeharika.nq@aksolutionsandservices.com</a></div>
              <div><small>PHONE</small><a href="tel:+917999937722">+91 79999 37722</a></div>
              <div><small>LOCATION</small><span>Hyderabad, Telangana, India</span></div>
              <div><small>WEB</small><span>aksolutionsandservices.com</span></div>
            </div>
          </div>
        </section>
      </main>

      <footer className="footer">
        <div>
          <div className="footer-brand"><span>AK</span> SOLUTIONS AND SERVICES</div>
          <p>Ideas. Solutions. Impact.</p>
        </div>
        <div className="footer-links">
          <a href="#home">Home</a><a href="#services">Services</a><a href="#about">About</a><a href="#contact">Contact</a>
        </div>
        <div className="copyright">© {new Date().getFullYear()} AK Solutions and Services. All rights reserved.</div>
      </footer>
    </div>
  );
}

export default App;